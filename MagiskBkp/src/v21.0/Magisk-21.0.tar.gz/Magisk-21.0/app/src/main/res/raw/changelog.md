## v8.0.0

- 100% full app rewrite! Will highlight functional changes below.
- Add detailed device info in home screen to assist user installation
- Support Magisk v21.0 communication protocol
- Support patching modern Samsung `AP.tar`
