## v8.0.6

- Minor UI changes
- Update internal scripts

## v8.0.5

- Fix sepolicy rule copying
